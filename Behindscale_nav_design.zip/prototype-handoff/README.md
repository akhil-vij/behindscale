# behindscale — Option C prototype: review handoff

Clickable prototype of the accepted IA (Option C). Open `home.dc.html` in a browser
and click through — all ten surfaces cross-link. Amber dashed notes are prototype
annotations, not product UI.

## Page map (file → intended URL)

| File | URL it stands for | What to review |
|---|---|---|
| home.dc.html | / | Landing deltas only: nav Problems·Patterns·Interview, CTA → /problems, trust-band wordmarks → company pages where built. Single CTA kept. |
| problems.dc.html | /problems (301 ← /catalog) | The workbench: all 41 real articles / 14 classes from the live catalog; client-side search, company filter, count line, empty state; group headers → problem pages (2 built). |
| problem-ambiguous-timeouts.dc.html | /problems/ambiguous-timeouts° | FULL class page: Edition 1 verbatim in its web costume — provenance line, hand-written vantage rows, interview-corner card, dark simulator CTA, subscribe. Email furniture stripped (see notes). |
| problem-queue-backlog.dc.html | /problems/queue-backlog° | STARTER class page: auto-rows from each article JSON's cruxSummary + source attribution; no interview corner (no question cites it); honest subscribe copy. |
| company-stripe.dc.html | /companies/stripe | Rich company page: 3 walls rows, 6 pattern chips, 3 breakdown cards, "asked about their systems" question strip. |
| company-figma.dc.html | /companies/figma | Thin company page (template floor): 1 wall, 3 patterns, 1 card, no question strip, no padding. |
| article-stripe-idempotency.dc.html | /articles/stripe-idempotency | Deltas only, marked ①②③: source eyebrow → company page; plain-words "Part of:" line → problem page; "answers this question" chip. Body = live page verbatim. |
| interview.dc.html | /interview | Index: 1 real question card (launch set is 5); practice-card slot annotated, unrendered. |
| interview-how-do-you-prevent-double-payments.html | /interview/how-do-you-prevent-double-payments | The approved specimen, passed through; only nav + two Stripe links repointed into the prototype. |
| newsletter.dc.html | /newsletter | Pitch, Edition 1 entry → its problem page, signup. Subscribe copy limited to what the cadence guarantees. |

° Plain-words placeholder slugs — final naming is an editorial call per class.

## Verification findings (need your ruling)

1. **Stripe count.** Your note said the live library has a third Stripe breakdown
   (stripe-docdb-data-movement). The live catalog lists **2** — docdb is not on it.
   The prototype renders all 3 (the bundle JSON is real) with the docdb card and
   the header count amber-flagged "not yet on the catalog." Confirm which ships.
2. **DoorDash is not single-breakdown.** Live catalog shows 2 (rabbitmq-kafka +
   aperture). Per your fallback instruction, the thin company page is **Figma**
   (a true single: figma-postgres-sharding, built from its live card).
3. **14 problem classes on the live catalog, not 15.** The workbench renders 14.
   ("Problem 1 of 15" was email furniture and stays email-side regardless.)

## Content decisions inside the allowed framing license

- Email furniture stripped from the full class page per the accepted H1 amendment:
  masthead, "Edition 1 · Ambiguous failure" subject label, "Problem 1 of 15 · 5 min,"
  and the next-week teaser live in the email only. A provenance line
  ("First sent as Edition 1 · updated as new evidence lands") replaces them —
  no send date shown because none exists in the data.
- Two inline "this week's" phrasings became "the class's" on the web costume;
  everything else in the edition body is verbatim from edition-01.md.
- Starter-page lede reuses Edition 1's own teaser line for this class ("the queue
  you added to protect your system becomes the thing that takes it down").
- Pattern chips render neutral (border + secondary text): pattern categories are
  not in the data, so no colors were invented. The purple chip treatment appears
  only where the approved interview specimen specifies it.
- Cards/rows for articles without bundle JSONs are transcribed from the live
  catalog (titles, dates, one-liners, pattern names) — nothing invented.

## Link policy

Built pages link to each other; everything else (pattern pages, the other 39
articles, artifacts, originals) links to the live site — the prototype's long
tail is real. The docdb article link points at its would-be live URL and may 404
until published.

## Reserved slots (shown, unrendered)

- Avatar: dashed circle right of search in every nav — inserts without reflow.
- Practice: dashed card at the bottom of /interview — phase 2 docks there plus a
  button on question pages; phase 1 drills need no slot.

## Out of scope this pass

/companies index (footers link Stripe + Figma directly), the 12 other problem
pages, the other 4 question pages, pattern pages, accounts/auth, working search
submission on /newsletter (input is non-functional).

## Source materials used

uploads/Bundle/* (11 article JSONs, edition-01.md, both specimens,
interview-double-payments.json) + live behindscale.com (/, /catalog,
/articles/stripe-idempotency) fetched 2026-08-13.
